#ifndef DETECTOR_H
#define DETECTOR_H

class Detector
{
public:
    Detector();
};

#endif // DETECTOR_H
