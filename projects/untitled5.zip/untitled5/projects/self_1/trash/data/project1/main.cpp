#include "haha.h"

/*
 * 这是一堆很长很长的注释
 * 会对我产生很大的影响
 * 因此我需要把它给去掉
 */

/*asd*/
int main()//这是Main函数
{
}
