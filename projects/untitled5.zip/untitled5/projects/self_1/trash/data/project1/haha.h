#include "haha2.h"

struct Class
{
}
