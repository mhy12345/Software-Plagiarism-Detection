#include "SearchStrategy.h"
SearchStrategy::~SearchStrategy()
{
}
