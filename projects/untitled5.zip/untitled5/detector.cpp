#include "detector.h"

Detector::Detector()
{
}
