#include<stdio.h>

int main(_){
return scanf("%d%d",(short*)&_,((short*)&_)+1),printf("%d",(_>>16)+_&0xffff),0;
} 
