/*
 * Problem:1000
 * Author:PYC
 */

#include <cstdio>

using namespace std;

int main(){
	int a,b;
	scanf("%d%d",&a,&b);
	printf("%d\n",a+b);
	return 0;
}
